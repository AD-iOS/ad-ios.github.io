# README.md
### 存放log日誌用

#### /var/AD/log/反向域名/

#### 示例: /var/AD/log/com.xcode.ad/
#### log文件和文件名自己創建