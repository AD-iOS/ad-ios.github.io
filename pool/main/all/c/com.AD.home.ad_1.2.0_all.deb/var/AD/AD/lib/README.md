# README.md
## /var/AD/AD/lib
### 存放各種庫用