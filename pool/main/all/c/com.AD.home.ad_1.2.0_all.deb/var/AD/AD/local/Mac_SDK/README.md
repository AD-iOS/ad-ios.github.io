# README.md

### 除非您需要使用 Mac SDK 否則這個 ln_mac_sdk.sh 腳本請不要運行

### 非開發者,和沒有xcode的開發者可以忽略掉本目錄
- 因為 您沒有 MacOS 的 SDK
