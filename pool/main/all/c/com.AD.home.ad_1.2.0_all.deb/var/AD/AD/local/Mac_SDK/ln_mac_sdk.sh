#!/bin/zsh

# Please adjust the path of the SDK according to your own MacOS SDK.

ln -s /Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.*