# README.md

### 除非您需要使用 iOS SDK 否則這個 ln_ios_sdk.sh 腳本請不要運行
- 因為他會把你的無根 theos 中的 sdks 裡面的 iOS SDK 全部符號鏈鏈接到當前目錄(iOS_SDK)中

### 如果您沒有 iOS theos 套件或者有了theos但是沒有 iOS SDK 也不要運行 ln_ios_sdk.sh 腳本 因為你的設備中沒有 iOS theos 或者 iOS SDK