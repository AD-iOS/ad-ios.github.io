# AD

#### 這是什麼東西?
- AD 的私有庫
- AD 的工作目錄

#### 安裝
- 使用下面的命令來安裝
```bash
cd /var/
git clone https://github.com/AD-devs/AD
```
- 權限不足請使用 sudo -i 或者 su root 來獲取root權限後再來操作

#### 建議添加的環境變量
```bash
export AD_PRIVATE_ROOT="/var/AD/AD"

export AD_INCLUDE_PATH="${AD_PRIVATE_ROOT}/include" # 添加 include 頭文件目錄

export AD_LOCAL_INCLUDE_PATH="${AD_PRIVATE_ROOT}/local/include" # 添加 local/include 的頭文件目錄

export AD_LIB_PATH="${AD_PRIVATE_ROOT}/lib" # 添加 lib 庫目錄

export AD_LOCAL_LIB_PATH="${AD_PRIVATE_ROOT}/local/lib" # 添加 local/lib 庫目錄
```