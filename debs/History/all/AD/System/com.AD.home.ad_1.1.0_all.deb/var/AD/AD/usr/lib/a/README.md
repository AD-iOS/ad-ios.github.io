# README.md
## /var/AD/AD/lib/a
### 此為靜態庫目錄存放靜態庫 .a 擴展名的文件用