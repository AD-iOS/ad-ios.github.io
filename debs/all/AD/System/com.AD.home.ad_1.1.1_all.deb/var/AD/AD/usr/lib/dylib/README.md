# README.md
## /var/AD/AD/lib/dylib
### 此為動態庫目錄存放動態庫 .dylib 擴展名的文件用