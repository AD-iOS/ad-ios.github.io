# README.md
## /var/AD/AD/lib/so
### 此為so動態庫目錄存放動態庫 .so 擴展名的文件用